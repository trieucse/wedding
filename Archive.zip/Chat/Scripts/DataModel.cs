using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataModel
{
    public  string Name;
    public  int Price;
    public  int Amount;

    public DataModel(string name, int price, int amount)
    {
        Name = name;
        Price = price;
        Amount = amount;
    }
   
}
