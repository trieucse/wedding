using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Mirror.Examples.Chat
{
    public class ChatUI : NetworkBehaviour
    {
        [Header("UI Elements")]
        [SerializeField] Text chatHistory;
        [SerializeField] Scrollbar scrollbar;
        [SerializeField]  GameObject itemPrefab;
        // This is only set on client to the name of the local player
        internal static string localPlayerName;
        List<DataModel> dataModels = new List<DataModel>();
         List<DataModel> buyList = new List<DataModel>();
        internal static readonly Dictionary<NetworkConnectionToClient, string> connNames = new Dictionary<NetworkConnectionToClient, string>();

        public void Start(){
            Debug.Log("Start");
            dataModels.Add(new DataModel("ga", 200,3));
            dataModels.Add(new DataModel("cola", 400,3));
            dataModels.Add(new DataModel("banana", 100,4));

            foreach (var item in dataModels)
            {
                GameObject productItem = Instantiate(itemPrefab);
                Button btnComponent = productItem.GetComponent<Button>();
                Text nameComponent = productItem.transform.Find("Name").GetComponent<Text>();
                Text priceComponent = productItem.transform.Find("Price").GetComponent<Text>();
                Image imageComponent = productItem.transform.Find("Image").GetComponent<Image>();
               
                if (nameComponent != null)
                {
                    nameComponent.text = item.Name;
                }
                 if (priceComponent != null)
                {
                    priceComponent.text = item.Price.ToString() + " VND"   ;
                }

                if (imageComponent != null)
                {
                    imageComponent.sprite = Resources.Load<Sprite>("Images/" + item.Name);
                }
                btnComponent.onClick.AddListener(()=>SendMessage(item));
   
                productItem.transform.SetParent(GameObject.Find("ListProduct").transform, false);
            
            }
          
        }

        public override void OnStartServer()
        {
            connNames.Clear();
            Debug.Log("OnStartServer");
        }

        public override void OnStartClient()
        {
            Debug.Log("OnStartClient");
        }

        [Command(requiresAuthority = false)]
        void CmdSend(string message, NetworkConnectionToClient sender = null)
        {
            if (!connNames.ContainsKey(sender))
                connNames.Add(sender, sender.identity.GetComponent<Player>().playerName);

            if (!string.IsNullOrWhiteSpace(message))
                RpcReceive(connNames[sender], message.Trim());
        }

        [ClientRpc]
        void RpcReceive(string playerName, string message)
        {
            string prettyMessage = playerName == localPlayerName ?
                $"<color=red>{playerName}:</color> {message}" :
                $"<color=blue>{playerName}:</color> {message}";
           AppendMessage(prettyMessage);
        }

        void AppendMessage(string message)
        {
           StartCoroutine(AppendAndScroll(message));
        }

        IEnumerator AppendAndScroll(string message)
        {
           chatHistory.text += message + "\n";

            // it takes 2 frames for the UI to update ?!?!
            yield return null;
            yield return null;

            // slam the scrollbar down
            scrollbar.value = 0;
        }

        // Called by UI element ExitButton.OnClick
        public void ExitButtonOnClick()
        {
            // StopHost calls both StopClient and StopServer
            // StopServer does nothing on remote clients
            NetworkManager.singleton.StopHost();
        }

        // Called by OnEndEdit above and UI element SendButton.OnClick
        public void SendMessage(DataModel item)
        {
            string message = "";
            if (item != null)
            {
                message = item.Name;
            }
            CmdSend(message);
        }
       
    }
}
